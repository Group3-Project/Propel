#!/bin/sh
export PORT=80
node app.js