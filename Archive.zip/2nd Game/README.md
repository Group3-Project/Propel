Before running the server run install.bat or install.sh
